from tkinter import *

root = Tk()

# Creating a label

myLabel1 = Label(root, text="Welcome to my Program! Down below are buttons. Click on them to try it out!")
myLabel2 = Label(root, text="Author of program: Isaah Raleigh")
myLabel3 = Label(root, text="Note to teacher: I hope all buttons work!")
# Pushing it onto the screen

myLabel1.grid(row=0, column=0)
myLabel2.grid(row=1, column=0)
myLabel3.grid(row=2, column=0)

root.mainloop()