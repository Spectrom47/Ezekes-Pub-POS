from tkinter import *

root = Tk()

# Creating a label

myLabel = Label(root, text="Hello World")
# Pushing it onto the screen
myLabel.pack()

root.mainloop()