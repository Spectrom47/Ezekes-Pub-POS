from tkinter import *

root = Tk()

def myClick():
    myLabel = Label(root, text="You clicked on the button!")
    myLabel.pack()

myButton = Button(root, text="I am button 1", padx=50, pady=50, command=myClick, fg="white", bg="black")
myButton.pack()

root.mainloop()