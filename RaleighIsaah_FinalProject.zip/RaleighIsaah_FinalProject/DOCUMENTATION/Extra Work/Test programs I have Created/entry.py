from tkinter import *

root = Tk()

e = Entry(root, width=25, bg="black", fg="white", borderwidth=5)
e.pack()


def myClick():
    myLabel = Label(root, text="Hello " + e.get() + ", its nice to meet you")
    myLabel.pack()

myButton = Button(root, text="Enter Your Name above then click me", padx=50, pady=50, command=myClick, fg="white", bg="black")
myButton.pack()

root.mainloop()