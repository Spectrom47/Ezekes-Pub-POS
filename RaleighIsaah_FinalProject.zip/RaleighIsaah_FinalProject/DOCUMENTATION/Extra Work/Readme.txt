Within this directory, I have created a set of Tkinter applications to help myself learn how to create something. 
These applications that I have created got me to learn how to use the functionality of Tkinter and how to use it! 
It was very fun to mess around with!